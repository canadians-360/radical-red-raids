({
  name: "Aqua Fang",
  basePower: 80,
  type: "Water",
  category: "Physical",
  accuracy: 100,
  pp: 15,
  priority: 0,
  flags: {
    contact: 1,
    protect: 1,
    mirror: 1,
    bite: 1
  },
  secondary: {
    chance: 10,
    volatileStatus: "flinch"
  },
  target: "normal",
  contestType: "Beautiful"
})